# coding=utf-8

from .WatermarkRemover import WatermarkRemover

__version__ = '0.0.1'
__author__ = 'caviler@gmail.com'
